import { redirect } from 'next/navigation'
import React from 'react'

const LabPage = () => {

    redirect("/labs/chughtai-lhr")
  return (
     <>
     
     
     </> 
  )
}

export default LabPage