export type PatientProfile={
    id: string;
    name: string;
    email: string;
    phone: string;
    currentCity: string;
}



